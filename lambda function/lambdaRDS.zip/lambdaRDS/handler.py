# Configuration Values
import pymysql
import sys

REGION = 'us-east-1'

endpoint = "aws-simplified.cds5bp6fq21g.us-east-1.rds.amazonaws.com"
username = "admin"
password = "XiaoQingWa23319!"
database_name = "PREDICTION_DATABASE"


def extract_events(event):
    result=[]
    conn = pymysql.connect(endpoint,user=username,passwd=password,db=database_name)
    with conn.cursor() as cur:
        cur.execute("""SELECT PricePerUnit FROM sample WHERE Location = %s and Instance = %s and OS = %s and day=%s and month=%s and year=%s""" % (event["Location"], event["Instance"], event["OS"], event["day"], event["month"], event["year"]))
        cur.close()
        for row in cur:
            result.append(list(row))
        print("Data from RDS ...")
        print(result)

def lambda_handler(event,context):
    extract_events(event)





